# 🎬 Film App

An interactive **Film App** built using **HTML, CSS, and JavaScript**.  
This project allows users to explore movies, view details, and experience a responsive film browsing interface.



---

## ✨ Features
- 🎥 **Movie Listings** – Displays a collection of films with posters, titles, and release years
- 🔍 **Search Functionality** – Quickly find movies by name
- 📝 **Film Details** – View additional info such as genre, actors, and description
- 📱 **Responsive Design** – Works smoothly on desktop and mobile
- ⚡ **JavaScript DOM Manipulation** – Dynamic content updates and interactivity

---

## 🛠️ Tech Stack
- **HTML5** – Structure
- **CSS3** – Styling and layout
- **JavaScript (ES6)** – Interactivity and dynamic behavior

---

## 📸 Screenshots

![Film App Screenshot](screenshot.png)  
*(Replace `screenshot.png` with your actual screenshot path)*

---

## 🎯 Learning Outcomes
- Strengthened **JavaScript event handling and DOM manipulation**
- Built **search and filter functionality**
- Improved knowledge of **responsive web design** principles

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/your-username/film-app.git
cd film-app
